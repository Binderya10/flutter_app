import 'package:flutter_app/model/widget/news_model.dart';
import 'package:get/get.dart';

class globalState {
  RxList<NewsModel> list = <NewsModel>[].obs;
}